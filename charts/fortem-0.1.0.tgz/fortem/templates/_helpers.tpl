{{/*
Expand the name of the chart.
*/}}
{{- define "fortem.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "fortem.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "fortem.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels applied to every resource.
*/}}
{{- define "fortem.labels" -}}
helm.sh/chart: {{ include "fortem.chart" . }}
{{ include "fortem.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels — used in matchLabels and pod template labels.
*/}}
{{- define "fortem.selectorLabels" -}}
app.kubernetes.io/name: {{ include "fortem.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Component-scoped selector labels.
Usage: {{ include "fortem.componentSelectorLabels" (dict "root" . "component" "operator") }}
*/}}
{{- define "fortem.componentSelectorLabels" -}}
app.kubernetes.io/name: {{ include "fortem.name" .root }}
app.kubernetes.io/instance: {{ .root.Release.Name }}
app.kubernetes.io/component: {{ .component }}
{{- end }}

{{/*
Component-scoped full labels (selector + chart/version metadata).
Usage: {{ include "fortem.componentLabels" (dict "root" . "component" "operator") }}
*/}}
{{- define "fortem.componentLabels" -}}
helm.sh/chart: {{ include "fortem.chart" .root }}
{{ include "fortem.componentSelectorLabels" . }}
{{- if .root.Chart.AppVersion }}
app.kubernetes.io/version: {{ .root.Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .root.Release.Service }}
{{- end }}

{{/*
ServiceAccount name for a given component.
Usage: {{ include "fortem.serviceAccountName" (dict "root" . "component" "operator") }}
*/}}
{{- define "fortem.serviceAccountName" -}}
{{- if .root.Values.serviceAccount.create }}
{{- printf "%s-%s" (include "fortem.fullname" .root) .component | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- default "default" .root.Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{/*
Image reference helper. Combines registry, repository, and tag.
Usage: {{ include "fortem.image" (dict "registry" .Values.global.image.registry "repository" .Values.operator.image.repository "tag" .Values.global.image.tag) }}
*/}}
{{- define "fortem.image" -}}
{{- printf "%s/%s:%s" .registry .repository .tag }}
{{- end }}
